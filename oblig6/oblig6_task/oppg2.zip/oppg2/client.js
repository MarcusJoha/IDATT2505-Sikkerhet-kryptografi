const CryptoJS = require("crypto-js")
// const axios = require("axios")
// clconst fetch = require("node-fetch")


const SALT = "localhost"
const KEYSIZE = 512/8
const ITERATIONS = 2048

// register user constansts
const registerButton = document.querySelector("#reg-userbtn")
const reg_user_username = document.querySelector("#reg-username")
const reg_password = document.querySelector("#reg-password")

// login constants 
const loginButton = document.querySelector("#login-btn")
const login_username_input = document.querySelector("username")
const login_password_input = document.getElementById("password")


const getHash = (passwd, salt) => CryptoJS.PBKDF2(passwd, salt, {keySize: KEYSIZE, iterations: ITERATIONS}).toString()
/*

registerButton.addEventListener("click", async () => {
    let hashed = getHash(reg_password.value, reg_user_username.value + SALT)
    // console.log(hashed)
    try {
        let res = await axios.post("/users", {
            username: reg_user_username.value,
            passwd: reg_password.value
        })
        if (res.status === 201) {
            alert("User Created!")
            return
        }
    } catch (err) {
        if (err) {
            alert("Already taken")
        }
    }
})

*/

loginButton.addEventListener("click", () => {
    console.log("login button clicked!")
})
