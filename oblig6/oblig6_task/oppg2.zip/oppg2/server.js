const express = require('express')
const app = express()
const PORT = 8080

// import PBKDF2 from "crypto-js/PBKDF2"

const CryptoJS = require('crypto-js')
const jwt = require("jsonwebtoken")

const KEYSIZE = 512/8
const TOKEN =  "fadsofdasfgdsa"


const getHash = (passwd, salt) => {
    CryptoJS.PBKDF2(passwd, salt, {keySize: KEYSIZE, iterations: 2048,}).toString()
}

const createUser = (username, passwd) => {
    let salt = CryptoJS.lib.WordArray.random(KEYSIZE)
    let hash = getHash(passwd, salt)
    return {
        username: username,
        salt: salt,
        hash: hash
    }
}


const users = []

app.use(express.static(__dirname))
app.use(express.urlencoded({
    extended:true}))

app.use(express.json())

app.get("/", (req, res) => {
    res.status(200, {"Content-Type": "text/html" })
    res.sendFile("./index.html", {root: __dirname})
})


app.post("/users", (req, res) => {
    if (useres.includes(u => u.username === req.body["username"])) {
        res.status(409)
        res.send()
        return
    }
    users.push(createUser(req.body["username", req.body["password"]]))
    res.status(201)
    res.send()
})

app.post("/login", (req, res) => {
    let user = users.find(u => u.username = req.body["username"])
    if (user) {
        let hash = getHash(req.body["password"], user.salt)
        if (hash == user.hash) {
            res.status(201)
            res.json({token: jwt.sign(user.username, TOKEN)})
            return
        }
    }
    res.status(401)
    res.send()
})



app.listen(PORT, "localhost", () => {
    console.log(`Server listening on port: ${PORT}`)
})


